# Marktplaats Barcode Scanner (Android)

Scan een artikelnummer-barcode met de camera van je telefoon, en de app
toont direct de productgegevens - gelezen uit dezelfde `producten.xml`
die de Linux-apps (`marktplaats_productmanager.py` etc.) gebruiken.

## Belangrijk: dit is een broncode-project, geen kant-en-klare APK

Ik kan in deze omgeving geen Android SDK/emulator draaien, dus dit is een
**compleet, correct Android Studio-project** dat je zelf moet openen en
bouwen. Dat is een bewuste keuze: zo kun je het ook zelf aanpassen en
debuggen.

### Bouwen

1. Installeer [Android Studio](https://developer.android.com/studio) (gratis).
2. **Open** (niet "importeren") deze `android/`-map als project.
3. Android Studio herkent dat er geen Gradle-wrapper-jar aanwezig is en
   biedt aan om die te downloaden/synchroniseren - accepteer dat
   ("Sync Project with Gradle Files"). Dit gebeurt automatisch, geen
   handmatige stappen nodig.
4. Sluit je Android-telefoon aan (met USB-debugging aan) of gebruik een
   emulator, en klik op ▶️ Run.

### Syncthing-koppeling instellen

De app leest `producten.xml` rechtstreeks van je telefoon - dus die
map moet via Syncthing (of een vergelijkbare sync-app) op je telefoon
staan.

1. Zorg dat `producten.xml` binnen de map staat die Syncthing naar je
   telefoon synct. Als je `marktplaats_productmanager.py` nu een ander
   XML-pad gebruikt, verplaats het bestand (of pas het pad in
   Instellingen aan) zodat het binnen de gesyncte map valt.
2. Open de Marktplaats Scanner-app op je telefoon, tik op
   **"📁 Kies Syncthing-map"**, en selecteer die map. Dit hoeft maar
   één keer - de app onthoudt de keuze.
3. Scan een barcode. De app leest `producten.xml` telkens vers in bij
   elke scan, dus je ziet altijd de laatste gesyncte stand.

### Wat de app niet doet (bewuste keuzes)

- **Geen `omschrijving.txt` uit de productmap** - die txt-bestanden
  staan in losse mappen per artikelnummer (met foto's erbij), en het
  is niet vanzelfsprekend dat je die hele mappenstructuur ook naar je
  telefoon wil syncen. De app gebruikt daarom de `omschrijving`-kolom
  rechtstreeks uit de XML.
- **Alleen lezen, niet schrijven** - de app markeert dus niets als
  online/verkocht. Dat blijft een taak voor de desktop-apps. Wil je dat
  er ook een "markeer als verkocht"-knop in de Android-app komt (die
  dan naar dezelfde XML terugschrijft), dan kan dat als vervolgstap.

### Projectstructuur

```
android/
├── app/
│   ├── build.gradle.kts          - dependencies (CameraX, ML Kit, etc.)
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/nl/hernieuw/barcodescanner/
│       │   ├── MainActivity.kt   - camera, mapkeuze, scan-afhandeling
│       │   └── Product.kt        - datamodel + XML-parser (zelfde schema)
│       └── res/                  - layout, strings, iconen
├── build.gradle.kts
└── settings.gradle.kts
```

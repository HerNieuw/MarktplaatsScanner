# Geen extra regels nodig - minifyEnabled staat uit in de debug/release-config hierboven.

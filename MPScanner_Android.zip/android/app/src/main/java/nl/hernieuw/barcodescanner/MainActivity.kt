package nl.hernieuw.barcodescanner

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import androidx.documentfile.provider.DocumentFile
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import nl.hernieuw.barcodescanner.databinding.ActivityMainBinding
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var barcodeScanner: BarcodeScanner

    private var mapUri: Uri? = null
    private var laatsteGescandeCode: String? = null
    private var laatsteScanTijd: Long = 0
    private var scanPauze = false

    private val prefs by lazy { getSharedPreferences("scanner_prefs", Context.MODE_PRIVATE) }

    private val cameraPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { toegekend ->
        if (toegekend) {
            startCamera()
        } else {
            Toast.makeText(this, getString(R.string.camera_toestemming_nodig), Toast.LENGTH_LONG).show()
        }
    }

    private val mapKiezerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri ->
        if (uri != null) {
            // Permissie blijvend maken zodat we na een herstart niet
            // opnieuw hoeven te kiezen.
            contentResolver.takePersistableUriPermission(
                uri,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            prefs.edit().putString("map_uri", uri.toString()).apply()
            mapUri = uri
            toonMapPad(uri)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        cameraExecutor = Executors.newSingleThreadExecutor()
        barcodeScanner = BarcodeScanning.getClient()

        binding.btnKiesMap.setOnClickListener {
            mapKiezerLauncher.launch(null)
        }
        binding.btnScanOpnieuw.setOnClickListener {
            hervatScannen()
        }

        // Eerder gekozen map herstellen
        prefs.getString("map_uri", null)?.let { opgeslagen ->
            val uri = Uri.parse(opgeslagen)
            mapUri = uri
            toonMapPad(uri)
        }

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
            == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun toonMapPad(uri: Uri) {
        binding.tvMapPad.text = uri.path ?: uri.toString()
    }

    private fun startCamera() {
        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            val cameraProvider = cameraProviderFuture.get()

            val preview = androidx.camera.core.Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }

            val imageAnalysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .build()
                .also {
                    it.setAnalyzer(cameraExecutor) { imageProxy -> analyseerFrame(imageProxy) }
                }

            val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA

            try {
                cameraProvider.unbindAll()
                cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageAnalysis)
            } catch (e: Exception) {
                Log.e("MarktplaatsScanner", "Camera kon niet gestart worden", e)
            }
        }, ContextCompat.getMainExecutor(this))
    }

    @androidx.camera.core.ExperimentalGetImage
    private fun analyseerFrame(imageProxy: ImageProxy) {
        if (scanPauze) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            barcodeScanner.process(image)
                .addOnSuccessListener { barcodes -> verwerkBarcodes(barcodes) }
                .addOnFailureListener { e -> Log.e("MarktplaatsScanner", "Scan-fout", e) }
                .addOnCompleteListener { imageProxy.close() }
        } else {
            imageProxy.close()
        }
    }

    private fun verwerkBarcodes(barcodes: List<Barcode>) {
        val code = barcodes.firstOrNull()?.rawValue ?: return

        // Voorkom dat dezelfde code binnen 3 seconden opnieuw getriggerd wordt
        // (de camera ziet dezelfde barcode meerdere frames achter elkaar).
        val nu = System.currentTimeMillis()
        if (code == laatsteGescandeCode && nu - laatsteScanTijd < 3000) return
        laatsteGescandeCode = code
        laatsteScanTijd = nu

        runOnUiThread { verwerkGescandArtikelnummer(code) }
    }

    private fun verwerkGescandArtikelnummer(artikelnummer: String) {
        val uri = mapUri
        if (uri == null) {
            Toast.makeText(this, "Kies eerst de Syncthing-map (📁 knop bovenaan)", Toast.LENGTH_LONG).show()
            return
        }

        val map = DocumentFile.fromTreeUri(this, uri)
        val xmlBestand = map?.findFile("producten.xml")
        if (xmlBestand == null || !xmlBestand.exists()) {
            Toast.makeText(this, "producten.xml niet gevonden in de gekozen map", Toast.LENGTH_LONG).show()
            return
        }

        try {
            val producten = ProductXmlReader.leesProducten(this, xmlBestand.uri)
            val product = ProductXmlReader.zoekOpArtikelnummer(producten, artikelnummer)
            if (product == null) {
                Toast.makeText(this, "Geen product gevonden met artikelnummer '$artikelnummer'", Toast.LENGTH_LONG).show()
                return
            }
            toonProduct(product)
        } catch (e: Exception) {
            Log.e("MarktplaatsScanner", "Fout bij lezen producten.xml", e)
            Toast.makeText(this, "Fout bij lezen producten.xml: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun toonProduct(product: Product) {
        scanPauze = true

        val (statusTekst, statusKleur) = when {
            product.verkocht -> "💰 VERKOCHT" to "#FFA500"
            product.online -> "🌐 ONLINE" to "#4A9EFF"
            else -> "⚪ OFFLINE (nog niet geplaatst)" to "#AAAAAA"
        }

        binding.tvTitel.text = product.titel
        binding.tvStatus.text = statusTekst
        binding.tvStatus.setTextColor(android.graphics.Color.parseColor(statusKleur))

        if (product.verkocht && product.leverwijze == "ophalen") {
            val klant = product.klantNaam.ifBlank { "(geen naam ingevuld)" }
            val prijs = product.verkoopprijs.ifBlank { "?" }
            binding.tvVerificatie.text = "✅ OPHALEN - controleer: $klant - €$prijs"
            binding.tvVerificatie.visibility = android.view.View.VISIBLE
        } else {
            binding.tvVerificatie.visibility = android.view.View.GONE
        }

        val details = StringBuilder()
        fun regel(label: String, waarde: String) {
            if (waarde.isNotBlank()) details.append("$label: $waarde\n\n")
        }
        regel("Artikelnummer", product.artikelnummer)
        regel("Categorie", product.categorie)
        regel("Tijdsperiode", product.tijdsperiode)
        regel("Conditie", product.conditie)
        regel("Staat details", product.staatDetails)
        if (product.lengte.isNotBlank() || product.breedte.isNotBlank() || product.hoogte.isNotBlank()) {
            regel("Afmetingen (LxBxH)", "${product.lengte} x ${product.breedte} x ${product.hoogte} cm")
        }
        regel("Gewicht", if (product.gewicht.isNotBlank()) "${product.gewicht} kg" else "")
        if (product.waardeMin.isNotBlank() || product.waardeMax.isNotBlank()) {
            regel("Geschatte waarde", "${product.waardeMin} ~${product.waardeMax}")
        }
        regel("Vraagprijs", if (product.vraagprijs.isNotBlank()) "€${product.vraagprijs}" else "")
        regel("Opslaglocatie", listOf(product.opslaglocatie, product.sublocatie, product.rij)
            .filter { it.isNotBlank() }.joinToString(" / "))
        if (product.online && product.advertentieUrl.isNotBlank()) {
            regel("Advertentie-URL", product.advertentieUrl)
        }
        if (product.verkocht) {
            regel("Verkoopprijs", if (product.verkoopprijs.isNotBlank()) "€${product.verkoopprijs}" else "")
            regel("Verkoopdatum", product.verkoopdatum)
            regel("Leverwijze", when (product.leverwijze) {
                "ophalen" -> "📦 Ophalen"
                "verzenden" -> "🚚 Verzenden"
                else -> ""
            })
            regel("Marktplaatsnaam koper", product.klantNaam)
            when (product.leverwijze) {
                "ophalen" -> {
                    regel("Telefoonnummer", product.klantTelefoon)
                    regel("E-mail", product.klantEmail)
                    regel("Afspraak", product.ophaalAfspraak)
                }
                "verzenden" -> {
                    regel("Track & Trace", product.trackTrace)
                }
            }
        }
        details.append("\n").append(product.omschrijving)

        binding.tvDetails.text = details.toString().trim()
        binding.resultCard.visibility = android.view.View.VISIBLE
    }

    private fun hervatScannen() {
        binding.resultCard.visibility = android.view.View.GONE
        laatsteGescandeCode = null
        scanPauze = false
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        barcodeScanner.close()
    }
}

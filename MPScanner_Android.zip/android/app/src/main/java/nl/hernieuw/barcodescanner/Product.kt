package nl.hernieuw.barcodescanner

import android.content.Context
import android.net.Uri
import org.xmlpull.v1.XmlPullParser
import java.io.IOException

/**
 * Eén product, ingelezen uit producten.xml. Gebruikt een vrije map i.p.v.
 * vaste kolomvolgorde, zodat dit ook blijft werken als er in de desktop-apps
 * ooit een veld bijkomt - dit leest gewoon alles wat er in het bestand staat.
 *
 * Kolomnamen zijn identiek aan marktplaats_productmanager.py /
 * marktplaats_automater_gtk.py / marktplaats_barcode_scanner.py (Linux).
 */
data class Product(val velden: Map<String, String>) {
    val artikelnummer: String get() = velden["artikelnummer"] ?: ""
    val titel: String get() = velden["titel"] ?: ""
    val omschrijving: String get() = velden["omschrijving"] ?: ""
    val categorie: String get() = velden["categorie"] ?: ""
    val conditie: String get() = velden["conditie"] ?: ""
    val staatDetails: String get() = velden["staat_details"] ?: ""
    val online: Boolean get() = velden["online"]?.trim()?.lowercase() == "ja"
    val verkocht: Boolean get() = velden["verkocht"]?.trim()?.lowercase() == "ja"
    val advertentieUrl: String get() = velden["advertentie_url"] ?: ""
    val vraagprijs: String get() = velden["vraagprijs"] ?: ""
    val waardeMin: String get() = velden["waarde_min"] ?: ""
    val waardeMax: String get() = velden["waarde_max"] ?: ""
    val lengte: String get() = velden["lengte"] ?: ""
    val breedte: String get() = velden["breedte"] ?: ""
    val hoogte: String get() = velden["hoogte"] ?: ""
    val gewicht: String get() = velden["gewicht"] ?: ""
    val tijdsperiode: String get() = velden["tijdsperiode"] ?: ""
    val opslaglocatie: String get() = velden["opslaglocatie"] ?: ""
    val sublocatie: String get() = velden["sublocatie"] ?: ""
    val rij: String get() = velden["rij"] ?: ""
    val verkoopprijs: String get() = velden["verkoopprijs"] ?: ""
    val verkoopdatum: String get() = velden["verkoopdatum"] ?: ""
    val leverwijze: String get() = velden["leverwijze"]?.trim()?.lowercase() ?: ""
    val klantNaam: String get() = velden["klant_naam"] ?: ""
    val klantTelefoon: String get() = velden["klant_telefoon"] ?: ""
    val klantEmail: String get() = velden["klant_email"] ?: ""
    val ophaalAfspraak: String get() = velden["ophaal_afspraak"] ?: ""
    val trackTrace: String get() = velden["track_trace"] ?: ""
}

object ProductXmlReader {

    /**
     * Leest alle producten uit producten.xml. Elk <product>-element bevat
     * platte tekst-subelementen, bv.:
     *   <product><artikelnummer>A51010801</artikelnummer><titel>...</titel>...</product>
     */
    fun leesProducten(context: Context, xmlUri: Uri): List<Product> {
        val producten = mutableListOf<Product>()
        val input = context.contentResolver.openInputStream(xmlUri)
            ?: throw IOException("Kon producten.xml niet openen - is de map/toestemming nog geldig?")

        input.use { stream ->
            val parser: XmlPullParser = android.util.Xml.newPullParser()
            parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
            parser.setInput(stream, "UTF-8")

            var huidigeVelden: MutableMap<String, String>? = null
            var huidigVeldNaam: String? = null
            var tekstBuffer = StringBuilder()

            var event = parser.eventType
            while (event != XmlPullParser.END_DOCUMENT) {
                when (event) {
                    XmlPullParser.START_TAG -> {
                        val tag = parser.name
                        if (tag == "product") {
                            huidigeVelden = mutableMapOf()
                        } else if (huidigeVelden != null) {
                            huidigVeldNaam = tag
                            tekstBuffer = StringBuilder()
                        }
                    }
                    XmlPullParser.TEXT -> {
                        if (huidigVeldNaam != null) {
                            tekstBuffer.append(parser.text)
                        }
                    }
                    XmlPullParser.END_TAG -> {
                        val tag = parser.name
                        if (tag == "product") {
                            huidigeVelden?.let { producten.add(Product(it)) }
                            huidigeVelden = null
                        } else if (huidigVeldNaam == tag && huidigeVelden != null) {
                            huidigeVelden[tag] = tekstBuffer.toString().trim()
                            huidigVeldNaam = null
                        }
                    }
                }
                event = parser.next()
            }
        }
        return producten
    }

    fun zoekOpArtikelnummer(producten: List<Product>, artikelnummer: String): Product? {
        val zoek = artikelnummer.trim()
        return producten.firstOrNull { it.artikelnummer.trim() == zoek }
    }
}
